package com.seagull.avt.cli;

import com.seagull.avt.core.AxmlPatch;
import com.seagull.avt.core.SignUtil;
import com.seagull.avt.core.ZipAlignWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

/** 桌面端命令行，用于在构建机上先验证核心逻辑（不依赖 Android）。 */
public class AvtCli {

    public static void main(String[] args) throws Exception {
        String cmd = args[0];
        if ("read".equals(cmd)) {
            byte[] m = ZipAlignWriter.extractEntry(new File(args[1]), "AndroidManifest.xml");
            String[] v = AxmlPatch.readVersion(m);
            System.out.println("versionName=" + v[0]);
            System.out.println("versionCode=" + v[1]);
            System.out.println("minSdk=" + AxmlPatch.readMinSdk(m));
        } else if ("run".equals(cmd)) {
            // run <in> <out> <newName|-> <newCode|-> <p12> <minSdk>
            File in = new File(args[1]);
            File out = new File(args[2]);
            String newName = "-".equals(args[3]) ? null : args[3];
            Integer newCode = "-".equals(args[4]) ? null : Integer.valueOf(args[4]);
            byte[] p12 = readAll(new FileInputStream(args[5]));
            int minSdk = Integer.parseInt(args[6]);

            byte[] m = ZipAlignWriter.extractEntry(in, "AndroidManifest.xml");
            String[] old = AxmlPatch.readVersion(m);
            System.out.println("原 versionName=" + old[0] + " versionCode=" + old[1] + " minSdk=" + AxmlPatch.readMinSdk(m));

            byte[] nm = AxmlPatch.patch(m, newName, newCode);
            File tmp = File.createTempFile("avt_repack", ".apk");
            tmp.deleteOnExit();
            ZipAlignWriter.rewrite(in, tmp, "AndroidManifest.xml", nm);
            System.out.println("重打包完成: " + tmp.length() + " 字节，开始签名");
            SignUtil.sign(tmp, out, p12, SignUtil.PASS, minSdk);
            System.out.println("输出: " + out.getAbsolutePath());
            System.out.println("自验: " + SignUtil.verify(out, minSdk));
            String[] chk = AxmlPatch.readVersion(ZipAlignWriter.extractEntry(out, "AndroidManifest.xml"));
            System.out.println("新 versionName=" + chk[0] + " versionCode=" + chk[1]);
        } else if ("repack".equals(cmd)) {
            // repack <in> <out> <newName|-> <newCode|->
            File in = new File(args[1]);
            File out = new File(args[2]);
            String newName = "-".equals(args[3]) ? null : args[3];
            Integer newCode = "-".equals(args[4]) ? null : Integer.valueOf(args[4]);
            byte[] m = ZipAlignWriter.extractEntry(in, "AndroidManifest.xml");
            byte[] nm = AxmlPatch.patch(m, newName, newCode);
            ZipAlignWriter.rewrite(in, out, "AndroidManifest.xml", nm);
            System.out.println("repack完成: " + out.getAbsolutePath() + " " + out.length() + " 字节");
            String[] chk = AxmlPatch.readVersion(ZipAlignWriter.extractEntry(out, "AndroidManifest.xml"));
            System.out.println("新 versionName=" + chk[0] + " versionCode=" + chk[1]);
        } else if ("sign".equals(cmd)) {
            // sign <in> <out> <p12> <minSdk>
            byte[] p12 = readAll(new FileInputStream(args[3]));
            SignUtil.sign(new File(args[1]), new File(args[2]), p12, SignUtil.PASS, Integer.parseInt(args[4]));
            System.out.println("已签名: " + args[2]);
            System.out.println(SignUtil.verify(new File(args[2]), Integer.parseInt(args[4])));
        } else if ("verify".equals(cmd)) {
            byte[] mm = ZipAlignWriter.extractEntry(new File(args[1]), "AndroidManifest.xml");
            int ms = AxmlPatch.readMinSdk(mm);
            System.out.println("(minSdk=" + ms + ") " + SignUtil.verify(new File(args[1]), ms));
        } else {
            System.out.println("用法: read|run|sign|verify ...");
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 15];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toByteArray();
    }
}
