package com.seagull.avt.core;

import com.android.apksig.ApkSigner;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 基于 apksig 的 V1+V2+V3 重签名与验签。 */
public final class SignUtil {

    public static final char[] PASS = "avtSignKey2026".toCharArray();

    private SignUtil() {}

    public static void sign(File in, File out, byte[] p12, char[] pass, int minSdk) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new ByteArrayInputStream(p12), pass);
        String alias = ks.aliases().nextElement();
        PrivateKey key = (PrivateKey) ks.getKey(alias, pass);
        List<X509Certificate> chain = new ArrayList<X509Certificate>();
        Certificate[] cs = ks.getCertificateChain(alias);
        if (cs == null || cs.length == 0) throw new IllegalStateException("PKCS12 中没有证书链");
        for (Certificate c : cs) chain.add((X509Certificate) c);

        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("avt", key, chain).build();
        ApkSigner signer = new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setMinSdkVersion(minSdk)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setV4SigningEnabled(false)
                .setCreatedBy("ApkVerTool")
                .build();
        signer.sign();
    }

    public static String verify(File apk) throws Exception {
        return verify(apk, 26);
    }

    public static String verify(File apk, int minSdk) throws Exception {
        com.android.apksig.ApkVerifier.Result r =
                new com.android.apksig.ApkVerifier.Builder(apk)
                        .setMinCheckedPlatformVersion(Math.min(minSdk, 24))
                        .build().verify();
        StringBuilder sb = new StringBuilder();
        sb.append("[v1=").append(r.isVerifiedUsingV1Scheme())
          .append(" v2=").append(r.isVerifiedUsingV2Scheme())
          .append(" v3=").append(r.isVerifiedUsingV3Scheme()).append("] ");
        if (r.containsErrors()) {
            sb.append("验签失败:");
            for (Object issue : r.getAllErrors())
                sb.append("\n  ERR ").append(issue).append(" (").append(issue.getClass().getSimpleName()).append(')');
            for (Object w : r.getWarnings())
                sb.append("\n  WARN ").append(w);
        } else {
            sb.append("验签通过");
        }
        return sb.toString().trim();
    }
}
