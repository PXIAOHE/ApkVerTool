package com.seagull.avt.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Android 二进制 AXML（AndroidManifest.xml）的版本号读写与字节级修补。纯 JDK，无 Android 依赖。 */
public final class AxmlPatch {

    public static final int TYPE_STRING = 0x03;
    public static final int TYPE_INT_DEC = 0x10;
    public static final int TYPE_INT_BOOLEAN = 0x12;

    private AxmlPatch() {}

    static final class Pool {
        int poolOff, poolSize, count, styleCount, flags, stringsStart, stylesStart;
        String[] strings;
        boolean utf8;
    }

    static final class Attr {
        int absOff;      // 属性结构在文件中的绝对偏移
        String name;     // 属性名（来自字符串池）
        int rawValue;    // 原始值字符串索引
        int type;        // typedValue 类型
        int data;        // typedValue 数据
    }

    // ---------------- 对外 API ----------------

    /** 返回 {versionName, versionCode}，任一可为 null。code 用十进制字符串表示。 */
    public static String[] readVersion(byte[] axml) throws Exception {
        Pool pool = parsePool(axml);
        int mOff = findElement(axml, pool, "manifest");
        if (mOff < 0) throw new Exception("AXML 中找不到 <manifest> 元素");
        String name = null, code = null;
        for (Attr a : readAttrs(axml, mOff, pool)) {
            if ("versionName".equals(a.name) && a.type == TYPE_STRING && a.data >= 0 && a.data < pool.count)
                name = pool.strings[a.data];
            else if ("versionCode".equals(a.name) && a.type == TYPE_INT_DEC)
                code = String.valueOf(a.data);
            else if ("versionCode".equals(a.name) && a.type == TYPE_STRING && a.data >= 0 && a.data < pool.count)
                code = pool.strings[a.data];
        }
        return new String[]{name, code};
    }

    /** 读 uses-sdk 的 minSdkVersion，找不到返回 24。 */
    public static int readMinSdk(byte[] axml) throws Exception {
        try {
            Pool pool = parsePool(axml);
            int uOff = findElement(axml, pool, "uses-sdk");
            if (uOff < 0) return 24;
            for (Attr a : readAttrs(axml, uOff, pool)) {
                if ("minSdkVersion".equals(a.name) && a.type == TYPE_INT_DEC) return a.data;
            }
        } catch (Throwable ignored) {}
        return 24;
    }

    /**
     * 修改 versionName / versionCode。
     * newName 为 null 表示不改名；newCode 为 null 表示不改码。
     * 输出为新的 AXML 字节（字符串池重建为 UTF-8 池）。
     */
    public static byte[] patch(byte[] axml, String newName, Integer newCode) throws Exception {
        if (newName == null && newCode == null) return axml;
        Pool pool = parsePool(axml);
        int mOff = findElement(axml, pool, "manifest");
        if (mOff < 0) throw new Exception("AXML 中找不到 <manifest> 元素");
        Attr nameAttr = null, codeAttr = null;
        for (Attr a : readAttrs(axml, mOff, pool)) {
            if ("versionName".equals(a.name)) nameAttr = a;
            else if ("versionCode".equals(a.name)) codeAttr = a;
        }
        byte[] out = axml;
        if (newCode != null) {
            if (codeAttr == null) throw new Exception("清单缺少 versionCode 属性，无法修改");
            out = patchInt(out, codeAttr.absOff + 16, newCode);
        }
        if (newName != null) {
            if (nameAttr == null) throw new Exception("清单缺少 versionName 属性（或非字符串型），无法修改");
            if (nameAttr.type != TYPE_STRING) throw new Exception("versionName 属性类型异常: 0x" + Integer.toHexString(nameAttr.type));
            out = rebuildPool(out, nameAttr.data, newName);
        }
        return out;
    }

    // ---------------- 解析 ----------------

    private static Pool parsePool(byte[] a) throws Exception {
        if (a.length < 40) throw new Exception("AXML 太短");
        if (u16(a, 0) != 0x0003) throw new Exception("不是有效的 AXML（magic 错误）");
        Pool p = new Pool();
        p.poolOff = 8;
        if (u16(a, 8) != 0x0001) throw new Exception("AXML 第一个子块不是字符串池");
        p.poolSize = u32(a, 12);
        p.count = u32(a, 16);
        p.styleCount = u32(a, 20);
        p.flags = u32(a, 24);
        p.stringsStart = u32(a, 28);
        p.stylesStart = u32(a, 32);
        p.utf8 = (p.flags & 0x100) != 0;
        if (p.count < 0 || p.count > 100000) throw new Exception("字符串池数量异常: " + p.count);
        p.strings = new String[p.count];
        for (int i = 0; i < p.count; i++) {
            int off = p.poolOff + p.stringsStart + u32(a, p.poolOff + 28 + 4 * i);
            p.strings[i] = p.utf8 ? readUtf8Str(a, off) : readUtf16Str(a, off);
        }
        return p;
    }

    /** 在池后元素中按元素名查找 START_ELEMENT 的绝对偏移，找不到返回 -1。 */
    private static int findElement(byte[] a, Pool p, String elementName) {
        int pos = p.poolOff + p.poolSize;
        while (pos + 8 <= a.length) {
            int type = u16(a, pos);
            int size = u32(a, pos + 4);
            if (size <= 0) return -1;
            if (type == 0x0102) { // START_ELEMENT
                int nameIdx = u32(a, pos + 20);
                if (nameIdx >= 0 && nameIdx < p.count && elementName.equals(p.strings[nameIdx])) return pos;
            }
            if (type != 0x0102 && type != 0x0100 && type != 0x0101 && type != 0x0180 && type != 0x0103 && type != 0x0104) return -1;
            pos += size;
        }
        return -1;
    }

    private static Attr[] readAttrs(byte[] a, int chunkOff, Pool p) throws Exception {
        int attrStart = u16(a, chunkOff + 24); // 相对 attrExt(chunkOff+16)
        int attrSize = u16(a, chunkOff + 26);
        int attrCount = u16(a, chunkOff + 28);
        if (attrSize <= 0) attrSize = 20;
        Attr[] out = new Attr[attrCount];
        for (int i = 0; i < attrCount; i++) {
            int base = chunkOff + 16 + attrStart + i * attrSize;
            Attr x = new Attr();
            x.absOff = base;
            int nameIdx = u32(a, base + 4);
            x.name = (nameIdx >= 0 && nameIdx < p.count) ? p.strings[nameIdx] : "";
            x.rawValue = u32(a, base + 8);
            x.type = a[base + 15] & 0xFF;
            x.data = u32(a, base + 16);
            out[i] = x;
        }
        return out;
    }

    // ---------------- 字符串池编解码 ----------------

    private static String readUtf8Str(byte[] a, int off) {
        int[] r1 = var8(a, off);         // [utf16len, next]
        int[] r2 = var8(a, r1[1]);       // [utf8len, next]
        byte[] b = Arrays.copyOfRange(a, r2[1], r2[1] + r2[0]);
        return decodeMutf8(b);
    }

    private static String readUtf16Str(byte[] a, int off) {
        int len32 = u32(a, off);
        int dataOff, len;
        if ((len32 & 0xFFFF0000) == 0) { len = len32; dataOff = off + 4; }
        else { len = u16(a, off); dataOff = off + 2; } // 兼容旧式 u16 长度
        if (len < 0 || dataOff + 2 * len + 2 > a.length) { // 长度异常则扫描 NUL
            dataOff = off + ((len32 & 0xFFFF0000) == 0 ? 4 : 2);
            int end = dataOff;
            while (end + 1 < a.length && !(a[end] == 0 && a[end + 1] == 0)) end += 2;
            len = (end - dataOff) / 2;
        }
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) sb.append((char) u16(a, dataOff + 2 * i));
        return sb.toString();
    }

    private static int[] var8(byte[] a, int off) {
        int b0 = a[off] & 0xFF;
        if ((b0 & 0x80) != 0) return new int[]{((b0 & 0x7F) << 8) | (a[off + 1] & 0xFF), off + 2};
        return new int[]{b0, off + 1};
    }

    private static String decodeMutf8(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length);
        int i = 0;
        while (i < b.length) {
            int x = b[i] & 0xFF;
            char c;
            if ((x & 0x80) == 0) { c = (char) x; i += 1; }
            else if ((x & 0xE0) == 0xC0) { c = (char) (((x & 0x1F) << 6) | (b[i + 1] & 0x3F)); i += 2; }
            else { c = (char) (((x & 0x0F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F)); i += 3; }
            sb.append(c);
        }
        return sb.toString();
    }

    static byte[] encodeMutf8(String s) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 0) { o.write(0xC0); o.write(0x80); }
            else if (c < 0x80) o.write(c);
            else if (c < 0x800) { o.write(0xC0 | (c >> 6)); o.write(0x80 | (c & 0x3F)); }
            else { o.write(0xE0 | (c >> 12)); o.write(0x80 | ((c >> 6) & 0x3F)); o.write(0x80 | (c & 0x3F)); }
        }
        return o.toByteArray();
    }

    // ---------------- 重建字符串池 ----------------

    /** 用 replacement 替换池中第 replaceIdx 个字符串，整池重编码为 UTF-8，返回新文件。 */
    private static byte[] rebuildPool(byte[] a, int replaceIdx, String replacement) throws Exception {
        Pool p = parsePool(a);
        if (replaceIdx < 0 || replaceIdx >= p.count) throw new Exception("versionName 池索引越界");
        String[] strings = p.strings.clone();
        strings[replaceIdx] = replacement;

        ByteArrayOutputStream blob = new ByteArrayOutputStream();
        int[] offs = new int[p.count];
        for (int i = 0; i < p.count; i++) {
            offs[i] = blob.size();
            byte[] b8 = encodeMutf8(strings[i]);
            writeVar8(blob, strings[i].length());
            writeVar8(blob, b8.length);
            blob.write(b8, 0, b8.length);
            blob.write(0);
        }
        while (blob.size() % 4 != 0) blob.write(0);
        byte[] stringsBlob = blob.toByteArray();

        byte[] styles = new byte[0];
        if (p.styleCount > 0 && p.stylesStart > 0 && p.poolSize > p.stylesStart)
            styles = Arrays.copyOfRange(a, p.poolOff + p.stylesStart, p.poolOff + p.poolSize);
        while (styles.length % 4 != 0) { /* styles 保持原样，整体池长再对齐 */ break; }

        int stringsStart = 28 + 4 * p.count;
        int stylesStart = stringsStart + stringsBlob.length;
        int poolSizeRaw = stylesStart + styles.length;
        int poolSize = (poolSizeRaw + 3) & ~3;

        byte[] pool = new byte[poolSize];
        put16(pool, 0, 0x0001);
        put16(pool, 2, 28);
        put32(pool, 4, poolSize);
        put32(pool, 8, p.count);
        put32(pool, 12, p.styleCount);
        put32(pool, 16, 0x100); // UTF-8
        put32(pool, 20, stringsStart);
        put32(pool, 24, stylesStart);
        for (int i = 0; i < p.count; i++) put32(pool, 28 + 4 * i, offs[i]);
        System.arraycopy(stringsBlob, 0, pool, stringsStart, stringsBlob.length);
        if (styles.length > 0) System.arraycopy(styles, 0, pool, stylesStart, styles.length);

        int prefix = p.poolOff; // 池在文件中的起始（root 头 8 字节 + 可能的前置）
        int tailLen = a.length - (p.poolOff + p.poolSize);
        byte[] out = new byte[prefix + poolSize + tailLen];
        System.arraycopy(a, 0, out, 0, prefix);
        System.arraycopy(pool, 0, out, prefix, poolSize);
        if (tailLen > 0) System.arraycopy(a, p.poolOff + p.poolSize, out, prefix + poolSize, tailLen);
        // 更新 root chunk 总大小
        if (u16(out, 0) == 0x0003) put32(out, 4, out.length);
        return out;
    }

    private static void writeVar8(ByteArrayOutputStream o, int n) {
        if (n <= 0x7F) o.write(n);
        else { o.write(0x80 | (n >> 8)); o.write(n & 0xFF); }
    }

    // ---------------- 基础工具 ----------------

    private static byte[] patchInt(byte[] a, int off, int value) {
        byte[] out = a.clone();
        put32(out, off, value);
        return out;
    }

    static int u16(byte[] a, int off) { return (a[off] & 0xFF) | ((a[off + 1] & 0xFF) << 8); }
    static int u32(byte[] a, int off) {
        return (a[off] & 0xFF) | ((a[off + 1] & 0xFF) << 8) | ((a[off + 2] & 0xFF) << 16) | ((a[off + 3] & 0xFF) << 24);
    }
    static void put16(byte[] a, int off, int v) { a[off] = (byte) v; a[off + 1] = (byte) (v >> 8); }
    static void put32(byte[] a, int off, int v) {
        a[off] = (byte) v; a[off + 1] = (byte) (v >> 8);
        a[off + 2] = (byte) (v >> 16); a[off + 3] = (byte) (v >> 24);
    }
}
