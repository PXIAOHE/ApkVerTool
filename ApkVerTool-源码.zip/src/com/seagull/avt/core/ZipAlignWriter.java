package com.seagull.avt.core;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * APK 重打包：替换 AndroidManifest.xml、剔除旧 V1 签名条目、保留其余条目内容与压缩方式，
 * STORED 条目数据 4 字节对齐（满足 targetSdk 30+ 的 resources.arsc 等要求）。
 * 输出不含任何签名块（旧 V2/V3 块随重写自然消失），需再走 SignUtil 签名。
 */
public final class ZipAlignWriter {

    private ZipAlignWriter() {}

    public static byte[] extractEntry(File zip, String name) throws IOException {
        ZipFile zf = new ZipFile(zip);
        try {
            ZipEntry e = zf.getEntry(name);
            if (e == null) throw new IOException("ZIP 中缺少条目: " + name);
            InputStream in = zf.getInputStream(e);
            try { return readAll(in); } finally { in.close(); }
        } finally {
            zf.close();
        }
    }

    public static void rewrite(File src, File dst, String replaceName, byte[] replaceBytes) throws IOException {
        rewrite(src, dst, replaceName, replaceBytes, false);
    }

    /** keepOldSignature=true：保留旧 META-INF V1 签名条目且不追加新签名（输出仅供二次处理，不可直接安装）。 */
    public static void rewrite(File src, File dst, String replaceName, byte[] replaceBytes, boolean keepOldSignature) throws IOException {
        CountingOutputStream out = new CountingOutputStream(
                new BufferedOutputStream(new FileOutputStream(dst), 1 << 16));
        List<Cd> cds = new ArrayList<Cd>();
        ZipFile zf = new ZipFile(src);
        try {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (isV1SignatureEntry(name) && !keepOldSignature) continue;
                byte[] data = readAll(zf.getInputStream(e));
                if (replaceName != null && name.equals(replaceName)) data = replaceBytes;

                boolean stored = e.getMethod() == ZipEntry.STORED;
                int method = stored ? ZipEntry.STORED : ZipEntry.DEFLATED;
                CRC32 crc = new CRC32();
                crc.update(data);
                byte[] payload = data;
                if (!stored) payload = deflate(data);

                byte[] nameBytes = name.getBytes("UTF-8");
                long localHeaderPos = out.count;
                int extraLen = 0;
                if (stored) {
                    // extractNativeLibs=false 的 APK 要求 lib/**/*.so 在 zip 内页对齐（4K/16K 设备），
                    // 统一按 16384 对齐（同时满足 4K 与 16K 页设备）；其余 STORED 条目 4 字节即可。
                    int align = name.startsWith("lib/") ? 16384 : 4;
                    int dataStart = (int) ((localHeaderPos + 30 + nameBytes.length) & 0x7FFFFFFF);
                    extraLen = (align - (dataStart & (align - 1))) & (align - 1);
                }
                long time = e.getTime();
                int[] dos = toDosTime(time);
                write32(out, 0x04034b50);
                write16(out, 20);
                write16(out, 0);
                write16(out, method);
                write16(out, dos[0]);
                write16(out, dos[1]);
                write32(out, (int) crc.getValue());
                write32(out, payload.length);
                write32(out, data.length);
                write16(out, nameBytes.length);
                write16(out, extraLen);
                out.write(nameBytes);
                for (int i = 0; i < extraLen; i++) out.write(0);
                out.write(payload);

                Cd cd = new Cd();
                cd.name = nameBytes;
                cd.crc = (int) crc.getValue();
                cd.compSize = payload.length;
                cd.size = data.length;
                cd.method = method;
                cd.localPos = localHeaderPos;
                cd.dosTime = dos[0];
                cd.dosDate = dos[1];
                cds.add(cd);
            }
        } finally {
            zf.close();
        }
        long cdStart = out.count;
        for (Cd cd : cds) {
            write32(out, 0x02014b50);
            write16(out, 0x031E);
            write16(out, 20);
            write16(out, 0);
            write16(out, cd.method);
            write16(out, cd.dosTime);
            write16(out, cd.dosDate);
            write32(out, cd.crc);
            write32(out, cd.compSize);
            write32(out, cd.size);
            write16(out, cd.name.length);
            write16(out, 0);
            write16(out, 0);
            write16(out, 0);
            write16(out, 0);
            write32(out, 0);
            write32(out, (int) cd.localPos);
            out.write(cd.name);
        }
        long cdEnd = out.count;
        write32(out, 0x06054b50);
        write16(out, 0);
        write16(out, 0);
        write16(out, cds.size());
        write16(out, cds.size());
        write32(out, (int) (cdEnd - cdStart));
        write32(out, (int) cdStart);
        write16(out, 0);
        out.close();
    }

    static boolean isV1SignatureEntry(String name) {
        String u = name.toUpperCase();
        if (!u.startsWith("META-INF/")) return false;
        String f = u.substring(9);
        return f.equals("MANIFEST.MF") || f.endsWith(".SF") || f.endsWith(".RSA")
                || f.endsWith(".DSA") || f.endsWith(".EC");
    }

    private static byte[] deflate(byte[] data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length / 2 + 16);
        Deflater d = new Deflater(Deflater.BEST_SPEED, true); // nowrap=true: raw deflate，ZIP 规范要求
        DeflaterOutputStream dos = new DeflaterOutputStream(bos, d);
        try {
            dos.write(data);
            dos.close();
        } catch (IOException ignored) {}
        d.end();
        return bos.toByteArray();
    }

    private static int[] toDosTime(long javaTime) {
        Calendar c = Calendar.getInstance();
        if (javaTime <= 0) c.set(2026, Calendar.JANUARY, 1, 0, 0, 0);
        else c.setTimeInMillis(javaTime);
        int year = Math.max(1980, c.get(Calendar.YEAR));
        int dosDate = ((year - 1980) << 9) | ((c.get(Calendar.MONTH) + 1) << 5) | c.get(Calendar.DAY_OF_MONTH);
        int dosTime = (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
        return new int[]{dosTime, dosDate};
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 15];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return bos.toByteArray();
    }

    static void write16(OutputStream o, int v) throws IOException {
        o.write(v & 0xFF);
        o.write((v >> 8) & 0xFF);
    }

    static void write32(OutputStream o, int v) throws IOException {
        o.write(v & 0xFF);
        o.write((v >> 8) & 0xFF);
        o.write((v >> 16) & 0xFF);
        o.write((v >> 24) & 0xFF);
    }

    private static final class Cd {
        byte[] name;
        int crc, compSize, size, method, dosTime, dosDate;
        long localPos;
    }

    private static final class CountingOutputStream extends OutputStream {
        private final OutputStream inner;
        long count = 0;
        CountingOutputStream(OutputStream inner) { this.inner = inner; }
        public void write(int b) throws IOException { inner.write(b); count++; }
        public void write(byte[] b, int off, int len) throws IOException { inner.write(b, off, len); count += len; }
        public void flush() throws IOException { inner.flush(); }
        public void close() throws IOException { inner.close(); }
    }
}
