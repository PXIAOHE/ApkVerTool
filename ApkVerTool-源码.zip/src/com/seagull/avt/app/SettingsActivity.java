package com.seagull.avt.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class SettingsActivity extends Activity {

    private static final int REQ_KEY = 21;

    private int cCard, cInk, cSub, cLine, cAccent, cFieldBg, cFieldStroke,
            cBtnSecondaryBg, cBtnSecondaryStroke;
    private boolean night;
    private String appliedMode;

    private SharedPreferences sp;
    private TextView tvKeyStatus;
    private EditText etKeyPass;
    private Switch swAuto, swDark;

    // ---- 应用级深浅色覆盖：auto / light / dark ----
    @Override
    protected void attachBaseContext(Context newBase) {
        SharedPreferences p = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE);
        String mode = p.getString("theme_mode", "auto");
        if (!p.contains("theme_mode")) {
            p.edit().putString("theme_mode", "auto").apply();
        }
        Configuration conf = new Configuration(newBase.getResources().getConfiguration());
        boolean nightNow;
        if ("auto".equals(mode)) {
            nightNow = (conf.uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
        } else {
            nightNow = "dark".equals(mode);
        }
        int ui = conf.uiMode & ~Configuration.UI_MODE_NIGHT_MASK
                | (nightNow ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
        conf.uiMode = ui;
        appliedMode = mode;
        super.attachBaseContext(newBase.createConfigurationContext(conf));
    }

    @Override
    protected void onResume() {
        super.onResume();
        String mode = getSharedPreferences("settings", MODE_PRIVATE).getString("theme_mode", "auto");
        if (!mode.equals(appliedMode)) {
            appliedMode = mode;
            recreate();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (getActionBar() != null) getActionBar().hide();
        initTheme();
        setupChrome();
        sp = getSharedPreferences("settings", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cBg());
        int pad = dp(16);
        root.setPadding(pad, dp(10), pad, dp(24));
        scroll.addView(root);
        setContentView(scroll);

        scroll.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                root.setPadding(root.getPaddingLeft(),
                        insets.getStableInsetTop() + dp(10),
                        root.getPaddingRight(),
                        insets.getStableInsetBottom() + dp(24));
                return insets;
            }
        });

        // ---- 顶栏 ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("⚙ 设置");
        title.setTextSize(21f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(cInk);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView done = textButton("完成");
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        header.addView(done);
        root.addView(header);
        root.addView(space(dp(10)));

        // ---- 卡片：外观 ----
        LinearLayout c0 = card();
        c0.addView(label("外观"));
        c0.addView(space(dp(8)));
        final String mode = sp.getString("theme_mode", "auto");
        swAuto = new Switch(this);
        swAuto.setText("跟随系统自动切换");
        swAuto.setTextSize(15f);
        swAuto.setTextColor(cInk);
        swAuto.setChecked("auto".equals(mode));
        swAuto.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton btn, boolean checked) {
                if (checked) {
                    sp.edit().putString("theme_mode", "auto").apply();
                } else {
                    // 关闭跟随时锁定当前视觉状态，避免跳变
                    sp.edit().putString("theme_mode", night ? "dark" : "light").apply();
                    swDark.setChecked(night);
                }
                applyTheme();
            }
        });
        c0.addView(swAuto);
        c0.addView(space(dp(6)));
        swDark = new Switch(this);
        swDark.setText("深色模式");
        swDark.setTextSize(15f);
        swDark.setTextColor(cInk);
        swDark.setEnabled(!"auto".equals(mode));
        swDark.setChecked(night);
        swDark.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton btn, boolean checked) {
                sp.edit().putString("theme_mode", checked ? "dark" : "light").apply();
                applyTheme();
            }
        });
        c0.addView(swDark);
        c0.addView(space(dp(6)));
        c0.addView(note("关闭「跟随系统」后，用「深色模式」开关手动指定深浅；改动立即生效，主页同步刷新。"));
        root.addView(c0);

        // ---- 卡片：签名设置 ----
        LinearLayout c1 = card();
        c1.addView(label("重签名"));
        c1.addView(space(dp(8)));
        Switch swResign = new Switch(this);
        swResign.setText("修改后重新签名");
        swResign.setTextSize(15f);
        swResign.setTextColor(cInk);
        swResign.setChecked(sp.getBoolean("resign", true));
        swResign.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton btn, boolean checked) {
                sp.edit().putBoolean("resign", checked).apply();
                toast(checked ? "已开启重签名" : "已切换为 MT 式不重签输出");
            }
        });
        c1.addView(swResign);
        c1.addView(space(dp(6)));
        c1.addView(note("关闭 = MT 式不重签输出：原签名数据原样保留，仅供 MT / LSPatch 等工具二次处理，不能直接安装。"));
        c1.addView(divider());
        c1.addView(label("自定义签名密钥（PKCS#12）"));
        c1.addView(space(dp(8)));
        tvKeyStatus = new TextView(this);
        tvKeyStatus.setTextSize(14f);
        tvKeyStatus.setTextColor(cAccent);
        tvKeyStatus.setTypeface(Typeface.DEFAULT_BOLD);
        c1.addView(tvKeyStatus);
        c1.addView(space(dp(8)));
        etKeyPass = new EditText(this);
        etKeyPass.setHint("密钥密码");
        etKeyPass.setTextSize(15f);
        etKeyPass.setTextColor(cInk);
        etKeyPass.setBackground(fieldBg());
        etKeyPass.setPadding(dp(14), dp(12), dp(14), dp(12));
        etKeyPass.setSingleLine(true);
        etKeyPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        etKeyPass.setText(sp.getString("key_pass", ""));
        c1.addView(etKeyPass);
        c1.addView(space(dp(10)));
        LinearLayout rowA = new LinearLayout(this);
        rowA.setOrientation(LinearLayout.HORIZONTAL);
        Button bImport = bigButton("📂 导入密钥文件…", true);
        bImport.setTextSize(13f);
        bImport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickKey();
            }
        });
        rowA.addView(bImport, new LinearLayout.LayoutParams(0, -2, 1f));
        rowA.addView(hSpace(dp(10)));
        Button bExport = bigButton("📤 导出当前密钥", true);
        bExport.setTextSize(13f);
        bExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportKey();
            }
        });
        rowA.addView(bExport, new LinearLayout.LayoutParams(0, -2, 1f));
        c1.addView(rowA);
        c1.addView(space(dp(10)));
        LinearLayout rowB = new LinearLayout(this);
        rowB.setOrientation(LinearLayout.HORIZONTAL);
        Button bClearKey = bigButton("↺ 恢复内置密钥", false);
        bClearKey.setTextSize(13f);
        bClearKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearKey();
            }
        });
        rowB.addView(bClearKey, new LinearLayout.LayoutParams(0, -2, 1f));
        rowB.addView(hSpace(dp(10)));
        Button bSavePass = bigButton("💾 保存密码设置", false);
        bSavePass.setTextSize(13f);
        bSavePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().putString("key_pass", etKeyPass.getText().toString()).apply();
                toast("已保存密钥密码");
            }
        });
        rowB.addView(bSavePass, new LinearLayout.LayoutParams(0, -2, 1f));
        c1.addView(rowB);
        root.addView(c1);

        // ---- 卡片：关于 ----
        LinearLayout c2 = card();
        c2.addView(label("关于本软件"));
        c2.addView(space(dp(6)));
        c2.addView(kv("软件作用",
                "查看并修改安卓 APK 的 versionName / versionCode；重打包时保持 resources.arsc 等条目的存储方式与 4 字节对齐；"
                        + "可选重新签名（V1+V2+V3）后输出可直接安装的新 APK，或按 MT 式保留原签名数据供其他工具二次处理。"));
        c2.addView(divider());
        c2.addView(kv("开发者", "Seagull（海鸥）· AI Agent 构建链：javac + D8 + apksig + 手搓 AXML / resources.arsc 编译器"));
        c2.addView(divider());
        c2.addView(kv("界面", "沉浸式系统栏；深色 / 浅色 / 跟随系统自动切换 + 手动锁定"));
        c2.addView(divider());
        c2.addView(label("更新日志"));
        c2.addView(space(dp(4)));
        c2.addView(note(
                "v1.4.5 · 修复输出的 APK 无法安装（Failed to extract native libraries）：lib/**/*.so 改为 zip 内 16KB 页对齐，满足 extractNativeLibs=false 的直接装载要求。\n"
              + "v1.4.4 · 修复重打包崩溃：保护 OutputStream 模板方法回调不被 R8 shrink 剥离。\n"
              + "v1.4.3 · 清剿最后一个漏网 lambda（点「开始修改」即崩的根因），混淆链彻底闭环。\n"
              + "v1.4.2 · 根治混淆回调链崩溃：修复 R8 库模型缺失 + 回调实现类整体保留。\n"
              + "v1.4.1 · 修复混淆版启动崩溃（javac 25 的 lambda 代理类与 R8 冲突，已全部改写为匿名内部类）。\n"
              + "v1.4 · 全量代码混淆加固（R8：shrink + optimize + obfuscate + 类名重打包）；核心引擎逆向成本大幅提高。\n"
              + "v1.3.4 · 修复设置页按钮行被横向间隔挤出屏幕的隐藏 bug（导入/导出此前不可见）；重签名说明精简；浅色玻璃按钮可见性增强；执行日志背景跟随深浅色。\n"
              + "v1.3.3 · 设置页新增「跟随系统」与「深色模式」双开关（立即生效、手动锁定）；签名密钥支持导入与导出当前密钥。\n"
              + "v1.3.2 · 应用名改为 ApkVerTool（安装器与桌面显示）；主页两大按钮升级液态玻璃材质。\n"
              + "v1.3.1 · 主页间距统一；日志区自适应撑满屏幕；新增底部使用说明卡与版本页脚。\n"
              + "v1.3 · 沉浸式状态栏与导航栏；深浅色主题适配；修正「不重签」模式说明。\n"
              + "v1.2 · 全新主页 UI；新增设置页与自定义密钥开关；新增应用图标与 resources.arsc。\n"
              + "v1.1 · 引擎自我更新演示。\n"
              + "v1.0 · 初版：AXML 字节级版本号修改 + 对齐重打包 + V1/V2/V3 重签名。"));
        root.addView(c2);

        refreshKeyStatus();
    }

    // ---------------- 主题与沉浸 ----------------

    private void initTheme() {
        night = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            cCard = 0xFF161F2E;
            cInk = 0xFFE5E7EB;
            cSub = 0xFF94A3B8;
            cLine = 0xFF293546;
            cAccent = 0xFF818CF8;
            cFieldBg = 0xFF111A29;
            cFieldStroke = 0xFF293546;
            cBtnSecondaryBg = 0xFF1E293B;
            cBtnSecondaryStroke = 0xFF3B4B66;
        } else {
            cCard = 0xFFFFFFFF;
            cInk = 0xFF111827;
            cSub = 0xFF6B7280;
            cLine = 0xFFE5E7EB;
            cAccent = 0xFF4F46E5;
            cFieldBg = 0xFFF9FAFB;
            cFieldStroke = 0xFFE5E7EB;
            cBtnSecondaryBg = 0xFFEEF2FF;
            cBtnSecondaryStroke = 0xFFC7D2FE;
        }
    }

    private int cBg() {
        return night ? 0xFF0B1220 : 0xFFF2F4F8;
    }

    private void applyTheme() {
        recreate();
    }

    private void setupChrome() {
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        int vis = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (!night) {
            vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(vis);
        w.getDecorView().setBackgroundColor(cBg());
    }

    // ---------------- UI 帮助 ----------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, h));
        return v;
    }

    private View hSpace(int w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(w, 1));
        return v;
    }

    private View divider() {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        int m = dp(10);
        lp.setMargins(0, m, 0, m);
        v.setLayoutParams(lp);
        v.setBackgroundColor(cLine);
        return v;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(cCard);
        g.setCornerRadius(dp(20));
        c.setBackground(g);
        int p = dp(18);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        int m = dp(12);
        lp.setMargins(0, m, 0, m);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(cSub);
        return t;
    }

    private TextView note(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13f);
        t.setTextColor(cSub);
        t.setLineSpacing(dp(3), 1f);
        return t;
    }

    private View kv(String k, String v) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label(k));
        box.addView(note(v));
        return box;
    }

    private TextView textButton(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(15f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(cAccent);
        int p = dp(10);
        t.setPadding(p, p / 2, p, p / 2);
        return t;
    }

    private GradientDrawable fieldBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(cFieldBg);
        g.setStroke(dp(1), cFieldStroke);
        g.setCornerRadius(dp(12));
        return g;
    }

    private Button bigButton(String s, boolean accent) {
        Button btn = new Button(this);
        btn.setText(s);
        btn.setTextColor(accent ? 0xFFFFFFFF : cAccent);
        btn.setTextSize(14f);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(0, dp(11), 0, dp(11));
        btn.setAllCaps(false);
        btn.setStateListAnimator(null);
        GradientDrawable g;
        if (accent) {
            g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{0xFF4F46E5, 0xFF0EA5E9});
        } else {
            g = new GradientDrawable();
            g.setColor(cBtnSecondaryBg);
            g.setStroke(dp(1), cBtnSecondaryStroke);
        }
        g.setCornerRadius(dp(14));
        btn.setBackground(g);
        return btn;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ---------------- 业务 ----------------

    private void refreshKeyStatus() {
        boolean useCustom = sp.getBoolean("use_custom", false);
        File f = new File(getFilesDir(), "custom_key.p12");
        if (useCustom && f.exists()) {
            tvKeyStatus.setText("● 当前使用：自定义密钥（" + f.length() / 1024 + " KB）");
        } else {
            tvKeyStatus.setText("● 当前使用：内置密钥");
        }
    }

    private void pickKey() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/x-pkcs12", "application/pkcs-12", "application/octet-stream"});
        startActivityForResult(i, REQ_KEY);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != REQ_KEY || res != RESULT_OK || data == null) return;
        try {
            ContentResolver cr = getContentResolver();
            InputStream in = cr.openInputStream(data.getData());
            File out = new File(getFilesDir(), "custom_key.p12");
            byte[] buf = new byte[1 << 15];
            int n;
            OutputStream os = new FileOutputStream(out);
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            in.close();
            os.close();
            sp.edit().putBoolean("use_custom", true).apply();
            refreshKeyStatus();
            toast("已导入自定义密钥，别忘了填写密码并保存");
        } catch (Throwable t) {
            toast("导入失败: " + t.getMessage());
        }
    }

    /** 导出当前生效的密钥（自定义优先，其次内置）到 Download / 应用目录。 */
    private void exportKey() {
        try {
            boolean useCustom = sp.getBoolean("use_custom", false);
            File custom = new File(getFilesDir(), "custom_key.p12");
            byte[] data;
            String name;
            if (useCustom && custom.exists()) {
                data = readAll(new FileInputStream(custom));
                name = "ApkVerTool_signkey_custom_" + System.currentTimeMillis() + ".p12";
            } else {
                data = readAll(getAssets().open("signkey.p12"));
                name = "ApkVerTool_signkey_builtin_" + System.currentTimeMillis() + ".p12";
            }
            File out = exportTarget(name);
            OutputStream os = new FileOutputStream(out);
            os.write(data);
            os.close();
            toast("已导出: " + out.getAbsolutePath());
        } catch (Throwable t) {
            toast("导出失败: " + t.getMessage());
        }
    }

    private File exportTarget(String base) {
        File out = null;
        try {
            File dl = android.os.Environment
                    .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (dl != null) {
                dl.mkdirs();
                out = new File(dl, base);
                OutputStream probe = new FileOutputStream(out);
                probe.close();
            }
        } catch (Throwable ignored) {
            out = null;
        }
        if (out == null) {
            File d = getExternalFilesDir(null);
            if (d == null) d = getFilesDir();
            d.mkdirs();
            out = new File(d, base);
        }
        return out;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 15];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toByteArray();
    }

    private void clearKey() {
        File f = new File(getFilesDir(), "custom_key.p12");
        if (f.exists()) f.delete();
        sp.edit().putBoolean("use_custom", false).apply();
        refreshKeyStatus();
        toast("已恢复内置密钥");
    }
}
