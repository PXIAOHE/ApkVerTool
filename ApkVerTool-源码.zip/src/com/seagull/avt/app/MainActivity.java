package com.seagull.avt.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.seagull.avt.core.AxmlPatch;
import com.seagull.avt.core.SignUtil;
import com.seagull.avt.core.ZipAlignWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 11;

    // 动态主题色板（深/浅色随系统）
    private int cBg, cCard, cInk, cSub, cLine, cAccent, cFieldBg, cFieldStroke,
            cHint, cLogCard, cLogText, cLogLabel, cBtnSecondaryBg, cBtnSecondaryStroke;
    private boolean night;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private EditText etName, etCode;
    private TextView tvInfo, tvLog;
    private File picked;
    private String appliedMode;

    // ---- 应用级深浅色覆盖：与设置页保持一致 ----
    @Override
    protected void attachBaseContext(Context newBase) {
        SharedPreferences p = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE);
        String mode = p.getString("theme_mode", "auto");
        if (!p.contains("theme_mode")) {
            p.edit().putString("theme_mode", "auto").apply();
        }
        Configuration conf = new Configuration(newBase.getResources().getConfiguration());
        boolean nightNow;
        if ("auto".equals(mode)) {
            nightNow = (conf.uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
        } else {
            nightNow = "dark".equals(mode);
        }
        conf.uiMode = conf.uiMode & ~Configuration.UI_MODE_NIGHT_MASK
                | (nightNow ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
        appliedMode = mode;
        super.attachBaseContext(newBase.createConfigurationContext(conf));
    }

    @Override
    protected void onResume() {
        super.onResume();
        String mode = getSharedPreferences("settings", MODE_PRIVATE).getString("theme_mode", "auto");
        if (!mode.equals(appliedMode)) {
            appliedMode = mode;
            recreate();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (getActionBar() != null) getActionBar().hide();
        String ft = getIntent() == null ? null : getIntent().getStringExtra("force_theme");
        if (ft != null) {
            String t = ("dark".equals(ft) || "light".equals(ft) || "auto".equals(ft)) ? ft : "auto";
            if (!t.equals(appliedMode)) {
                getSharedPreferences("settings", MODE_PRIVATE).edit().putString("theme_mode", t).apply();
                appliedMode = t;
                recreate();
                return;
            }
        }
        initTheme();
        android.util.Log.d("AvtTheme", "theme: mode=" + appliedMode + " night=" + night);
        setupChrome();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cBg);
        int pad = dp(16);
        root.setPadding(pad, dp(10), pad, dp(24));
        scroll.addView(root);
        setContentView(scroll);

        // 沉浸式：真实系统栏高用 stableInset（systemWindowInsetTop 在 Android 15+ 会掺入兼容层假 inset，导致双重下压）
        scroll.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                root.setPadding(root.getPaddingLeft(),
                        insets.getStableInsetTop() + dp(10),
                        root.getPaddingRight(),
                        insets.getStableInsetBottom() + dp(24));
                return insets;
            }
        });

        // ---- 顶栏 ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("APK 版本号修改器");
        title.setTextSize(21f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(cInk);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView btnSettings = textButton("⚙ 设置");
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        header.addView(btnSettings);
        root.addView(header);
        root.addView(space(dp(10)));

        // ---- 卡片一：选择 APK ----
        LinearLayout c1 = card();
        c1.addView(label("① 选择 APK 文件"));
        c1.addView(space(dp(10)));
        Button pick = glassButton("📂  选择 APK…");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pick();
            }
        });
        c1.addView(pick);
        c1.addView(space(dp(10)));
        tvInfo = new TextView(this);
        tvInfo.setText("尚未选择文件");
        tvInfo.setTextSize(14f);
        tvInfo.setTextColor(cSub);
        tvInfo.setLineSpacing(dp(3), 1f);
        c1.addView(tvInfo);
        root.addView(c1);

        // ---- 卡片二：新版本号 ----
        LinearLayout c2 = card();
        c2.addView(label("② 设置新版本号"));
        c2.addView(space(dp(10)));
        etName = field("新 versionName（留空 = 不改）", false);
        c2.addView(etName);
        c2.addView(space(dp(10)));
        etCode = fieldNum("新 versionCode（留空 = 不改）");
        c2.addView(etCode);
        c2.addView(space(dp(14)));
        Button go = glassButton("🚀 开始修改 →");
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRun();
            }
        });
        c2.addView(go);
        root.addView(c2);

        // ---- 卡片三：日志（自适应撑满剩余屏幕）----
        LinearLayout c3 = card(cLogCard);
        TextView logTitle = label("执行日志");
        logTitle.setTextColor(cLogLabel);
        c3.addView(logTitle);
        c3.addView(space(dp(8)));
        tvLog = new TextView(this);
        tvLog.setText("等待任务…\n");
        tvLog.setTextSize(12f);
        tvLog.setTextColor(cLogText);
        tvLog.setLineSpacing(dp(2), 1f);
        tvLog.setMovementMethod(new ScrollingMovementMethod());
        c3.addView(tvLog, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(-1, 0, 1f);
        lp3.setMargins(0, dp(12), 0, dp(12));
        c3.setLayoutParams(lp3);
        root.addView(c3);

        // ---- 卡片四：使用说明 ----
        LinearLayout c4 = card();
        c4.addView(label("💡 使用说明"));
        c4.addView(space(dp(8)));
        c4.addView(note(
                "· 输出默认保存到 Download 目录，若被系统拒绝写入则落到应用私有目录；\n"
              + "· 重签名开关与自定义 PKCS#12 密钥在右上角「设置」页；\n"
              + "· 关闭重签名 = MT 式不重签输出：原签名数据原样保留，仅供二次处理，不能直接安装；\n"
              + "· 改动过的 APK 想装上设备的唯一途径就是重新签名。"));
        root.addView(c4);

        TextView footer = new TextView(this);
        footer.setText("ApkVerTool v1.4.5 · Seagull（海鸥）");
        footer.setTextSize(12f);
        footer.setTextColor(cSub);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpF = new LinearLayout.LayoutParams(-1, -2);
        lpF.topMargin = dp(14);
        root.addView(footer, lpF);

        if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")
                != getPackageManager().PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 12);
        }
    }

    // ---------------- 主题与沉浸 ----------------

    private void initTheme() {
        night = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            cBg = 0xFF0B1220;
            cCard = 0xFF161F2E;
            cInk = 0xFFE5E7EB;
            cSub = 0xFF94A3B8;
            cLine = 0xFF293546;
            cAccent = 0xFF818CF8;
            cFieldBg = 0xFF111A29;
            cFieldStroke = 0xFF293546;
            cHint = 0xFF64748B;
            cLogCard = 0xFF060B14;
            cLogText = 0xFF86EFAC;
            cLogLabel = 0xFF94A3B8;
            cBtnSecondaryBg = 0xFF1E293B;
            cBtnSecondaryStroke = 0xFF3B4B66;
        } else {
            cBg = 0xFFF2F4F8;
            cCard = 0xFFFFFFFF;
            cInk = 0xFF111827;
            cSub = 0xFF6B7280;
            cLine = 0xFFE5E7EB;
            cAccent = 0xFF4F46E5;
            cFieldBg = 0xFFF9FAFB;
            cFieldStroke = 0xFFE5E7EB;
            cHint = 0xFF9CA3AF;
            cLogCard = 0xFFF8FAFC;
            cLogText = 0xFF334155;
            cLogLabel = 0xFF64748B;
            cBtnSecondaryBg = 0xFFEEF2FF;
            cBtnSecondaryStroke = 0xFFC7D2FE;
        }
    }

    private void setupChrome() {
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        int vis = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (!night) {
            vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(vis);
        w.getDecorView().setBackgroundColor(cBg);
    }

    // ---------------- UI 帮助方法 ----------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, h));
        return v;
    }

    private LinearLayout card(int bg) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(20));
        c.setBackground(g);
        int p = dp(18);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        int m = dp(12);
        lp.setMargins(0, m, 0, m);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout card() {
        return card(cCard);
    }

    private GradientDrawable gradBg() {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{0xFF4F46E5, 0xFF0EA5E9});
        g.setCornerRadius(dp(14));
        return g;
    }

    private GradientDrawable fieldBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(cFieldBg);
        g.setStroke(dp(1), cFieldStroke);
        g.setCornerRadius(dp(12));
        return g;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(cSub);
        return t;
    }

    private TextView note(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13f);
        t.setTextColor(cSub);
        t.setLineSpacing(dp(3), 1f);
        return t;
    }

    private TextView textButton(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(15f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(cAccent);
        int p = dp(10);
        t.setPadding(p, p / 2, p, p / 2);
        return t;
    }

    /** 液态玻璃按钮：半透明玻璃 + 顶部高光 + 泛光 + 亮描边 + 涟漪反馈，深浅色自适应；API 31+ 附加真实背景模糊。 */
    private Button glassButton(String s) {
        Button btn = new Button(this);
        btn.setText(s);
        btn.setTextSize(16f);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(0, dp(13), 0, dp(13));
        btn.setAllCaps(false);
        btn.setStateListAnimator(null);
        btn.setTextColor(night ? 0xFFF1F5F9 : 0xFF1E1B4B);
        btn.setBackground(new RippleDrawable(
                ColorStateList.valueOf(night ? 0x33818CF8 : 0x334F46E5),
                liquidGlass(), null));
        btn.setElevation(dp(3));
        try { // View.setBackgroundBlurRadius 为 API 31+，低版本静默跳过
            java.lang.reflect.Method m = View.class.getMethod("setBackgroundBlurRadius", int.class);
            m.invoke(btn, dp(10));
        } catch (Throwable ignored) {
        }
        return btn;
    }

    private Drawable liquidGlass() {
        // 层1：左上泛光
        GradientDrawable glow = new GradientDrawable();
        glow.setShape(GradientDrawable.RECTANGLE);
        glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setGradientRadius(dp(170));
        glow.setGradientCenter(0.2f, 0.05f);
        glow.setColors(night ? new int[]{0x334F46E5, 0x004F46E5}
                              : new int[]{0x4D4F46E5, 0x004F46E5});
        glow.setCornerRadius(dp(18));
        // 层2：半透明玻璃填充（顶部高光渐变）
        GradientDrawable fill = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                night ? new int[]{0x2EFFFFFF, 0x0FFFFFFF}
                      : new int[]{0xF0F4F8FF, 0xCCDDE7FF});
        fill.setCornerRadius(dp(18));
        // 层3：亮描边（中心透明，只留 1px 玻璃边）
        GradientDrawable border = new GradientDrawable();
        border.setCornerRadius(dp(18));
        border.setColor(0x00000000);
        border.setStroke(dp(1), night ? 0x59FFFFFF : 0xFF818CF8);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{glow, fill, border});
        ld.setLayerInset(1, dp(1), dp(1), dp(1), dp(1));
        return ld;
    }

    private Button bigButton(String s, boolean accent) {
        Button btn = new Button(this);
        btn.setText(s);
        btn.setTextSize(16f);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(0, dp(12), 0, dp(12));
        btn.setAllCaps(false);
        btn.setStateListAnimator(null);
        GradientDrawable g;
        if (accent) {
            btn.setTextColor(0xFFFFFFFF);
            g = gradBg();
        } else {
            btn.setTextColor(cAccent);
            g = new GradientDrawable();
            g.setColor(cBtnSecondaryBg);
            g.setStroke(dp(1), cBtnSecondaryStroke);
        }
        g.setCornerRadius(dp(14));
        btn.setBackground(g);
        return btn;
    }

    private EditText field(String hint, boolean number) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15f);
        e.setTextColor(cInk);
        e.setHintTextColor(cHint);
        e.setBackground(fieldBg());
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setSingleLine(true);
        if (number) e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private EditText fieldNum(String hint) {
        return field(hint, true);
    }

    // ---------------- 业务逻辑 ----------------

    private void log(final String s) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                tvLog.setText(tvLog.getText() + s + "\n");
            }
        });
    }

    private void toast(final String s) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.android.package-archive", "application/zip",
                "application/octet-stream", "application/x-zip-compressed"});
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    @SuppressLint("SetTextI18n")
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        try {
            ContentResolver cr = getContentResolver();
            InputStream in = cr.openInputStream(data.getData());
            picked = new File(getCacheDir(), "input.apk");
            copy(in, new FileOutputStream(picked));
            final byte[] m = ZipAlignWriter.extractEntry(picked, "AndroidManifest.xml");
            final String[] v = AxmlPatch.readVersion(m);
            ui.post(new Runnable() {
                @Override
                public void run() {
                    tvInfo.setText("当前 versionName = " + (v[0] == null ? "-" : v[0])
                            + "\n当前 versionCode = " + (v[1] == null ? "-" : v[1]));
                    etName.setText(v[0] == null ? "" : v[0]);
                    etCode.setText(v[1] == null ? "" : v[1]);
                }
            });
            log("已读入，目标 minSdk=" + AxmlPatch.readMinSdk(m));
        } catch (Throwable t) {
            log("读取失败: " + t);
        }
    }

    private void startRun() {
        if (picked == null || !picked.exists()) {
            toast("先选择 APK");
            return;
        }
        final String nn = etName.getText().toString().trim();
        final String nc = etCode.getText().toString().trim();
        if (nn.isEmpty() && nc.isEmpty()) {
            toast("至少填一个新版本号");
            return;
        }
        ui.post(new Runnable() {
            @Override
            public void run() {
                tvLog.setText("");
            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                doRun(nn, nc);
            }
        }).start();
    }

    private void doRun(String nn, String nc) {
        try {
            String newName = nn.isEmpty() ? null : nn;
            Integer newCode = nc.isEmpty() ? null : Integer.valueOf(nc);

            SharedPreferences sp = getSharedPreferences("settings", MODE_PRIVATE);
            boolean resign = sp.getBoolean("resign", true);
            byte[] p12;
            char[] pass;
            String keyDesc;
            if (sp.getBoolean("use_custom", false)) {
                File cf = new File(getFilesDir(), "custom_key.p12");
                if (cf.exists()) {
                    p12 = readAll(new FileInputStream(cf));
                    pass = sp.getString("key_pass", "").toCharArray();
                    keyDesc = "自定义密钥";
                } else {
                    p12 = readAll(getAssets().open("signkey.p12"));
                    pass = SignUtil.PASS;
                    keyDesc = "内置密钥（自定义密钥文件缺失，已回退）";
                }
            } else {
                p12 = readAll(getAssets().open("signkey.p12"));
                pass = SignUtil.PASS;
                keyDesc = "内置密钥";
            }

            byte[] m = ZipAlignWriter.extractEntry(picked, "AndroidManifest.xml");
            int minSdk = AxmlPatch.readMinSdk(m);
            byte[] nm = AxmlPatch.patch(m, newName, newCode);

            String base = "patched"
                    + (newName != null ? "_" + newName.replace('/', '_') : "")
                    + (newCode != null ? "_" + newCode : "")
                    + ".apk";

            File out = pickOutput(base);
            File tmp = File.createTempFile("avt", ".apk", getCacheDir());
            log("重打包中…（重签名: " + (resign ? "开" : "关") + "，密钥: " + keyDesc + "）");
            ZipAlignWriter.rewrite(picked, tmp, "AndroidManifest.xml", nm, !resign);

            if (resign) {
                log("签名中… (minSdk=" + minSdk + ")");
                SignUtil.sign(tmp, out, p12, pass, minSdk);
                tmp.delete();
                log("完成 → " + out.getAbsolutePath());
                log("自验: " + SignUtil.verify(out, minSdk));
            } else {
                copy(new FileInputStream(tmp), new FileOutputStream(out));
                tmp.delete();
                log("完成（未重签）→ " + out.getAbsolutePath());
                log("⚠ MT 式不重签输出：原签名数据已原样保留。");
                log("⚠ 注意：内容已改动，原签名在系统层面必然失效，输出仅供 MT/LSPatch 等工具继续处理，不能直接安装。");
            }
            String[] chk = AxmlPatch.readVersion(ZipAlignWriter.extractEntry(out, "AndroidManifest.xml"));
            log("新 versionName=" + chk[0] + " versionCode=" + chk[1]);
            toast("已输出: " + out.getName());
        } catch (Throwable t) {
            log("失败: " + t);
            toast("失败: " + t.getMessage());
        }
    }

    private File pickOutput(String base) {
        File out = null;
        try {
            File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (dl != null) {
                dl.mkdirs();
                out = new File(dl, base);
                OutputStream probe = new FileOutputStream(out);
                probe.close();
            }
        } catch (Throwable ignored) {
            out = null;
        }
        if (out == null) {
            File d = getExternalFilesDir(null);
            if (d == null) d = getFilesDir();
            d.mkdirs();
            out = new File(d, base);
        }
        return out;
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[1 << 15];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        out.close();
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 15];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toByteArray();
    }
}
