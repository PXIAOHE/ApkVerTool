# ApkVerTool v1.4.5 — APK 版本号修改器

纯 framework 代码、无任何第三方 UI 库的安卓工具 App：选择 APK →
读取/修改 versionName 与 versionCode → 对齐重打包 → V1+V2+V3 重签名 →
输出可直接安装的新 APK。附带 MT 式"不重签"输出模式、自定义 PKCS#12
签名密钥（导入/导出）、深浅色/跟随系统主题、沉浸式系统栏与液态玻璃按钮。

- 包名: `com.seagull.apkvertool`  versionName: 1.4.5  versionCode: 14
- minSdk 26 / targetSdk 28（无 resources.arsc 的极简包由 mkaxml.py + mkicon.py 手搓生成）

## 目录结构

```
├── build.sh                 # 一键构建脚本
├── proguard-rules.pro       # R8 混淆规则（含全部避坑注释）
├── mkaxml.py                # 手搓 AXML 编译器：二进制 AndroidManifest 生成
├── mkicon.py                # 应用图标 PNG + 最小 resources.arsc 生成器
├── pack.py                  # 组包（arsc 对齐 + 双 dex + assets）并调用 CLI 签名
├── signkey.p12              # 内置签名密钥（见下方说明）
└── src/
    ├── com/seagull/avt/core/   # 核心引擎（纯 JDK，桌面可测试）
    │   ├── AxmlPatch.java      #   AXML 字节级读写/改版本号（UTF-8/UTF-16 双池、MUTF-8）
    │   ├── ZipAlignWriter.java #   手写 ZIP 重打包（STORED 对齐：arsc 4 字节、lib/**/*.so 16KB 页）
    │   └── SignUtil.java       #   apksig 封装：V1+V2+V3 签名与验签
    ├── com/seagull/avt/cli/AvtCli.java    # 桌面 CLI（read/repack/run/sign/verify）
    └── com/seagull/avt/app/              # App UI（纯代码布局，无 XML 资源）
        ├── MainActivity.java
        └── SettingsActivity.java
```

## 构建依赖（libs/，未随源码分发，约 170MB）

| 文件 | 用途 | 获取（任选镜像） |
|---|---|---|
| r8.jar | R8/D8 编译器 | https://dl.google.com/android/maven2/com/android/tools/r8/9.5.22/r8-9.5.22.jar |
| apksig.jar | 签名库 | https://dl.google.com/android/maven2/com/android/tools/build/apksig/9.5.0-alpha08/apksig-9.5.0-alpha08.jar |
| android.jar | API16 完整库模型（java.* 齐全，R8 依赖识别必需） | https://repo1.maven.org/maven2/com/google/android/android/4.1.1.4/android-4.1.1.4.jar |
| android28.jar | API28 编译模型（javac -cp 用） | https://repo1.maven.org/maven2/org/robolectric/android-all/9-robolectric-4913185-2/android-all-9-robolectric-4913185-2.jar |
| core-oj.jar / core-libart.jar | D8 编 apksig 时的运行时模型 | 从设备 `/apex/com.android.art/javalib/` 拷贝 |

## 构建

```
mkdir libs && cd libs   # 放入上表 jar
cd .. && sh build.sh    # 产物 build/ApkVerTool-v1.4.5.apk
```

## 内置签名密钥

`signkey.p12`：alias `avt`，密码 `avtSignKey2026`，RSA-2048 自签
（CN=ApkVerTool, OU=Seagull, O=Seagull）。工具级密钥：所有输出 APK 同指纹。
换密钥：设置页「导入密钥文件」，或替换 assets/signkey.p12 后重编。

## 历史坑备忘（本工程实测踩过，规则文件内有对应注释）

1. javac 25 对 `--release 8` 的 lambda 生成代理类 → R8 拒绝 → 全部改匿名内部类
2. R8 9.5.22 对 `extends/implements` 条件 keep 不可靠 → 一律类名/包名锚定
3. R8 shrink 剥离"仅被库内部调用"的方法（Runnable.run、OutputStream.write(int)）→ keep 兜底
4. apksig 含 lambda → 单独 D8 编 classes2.dex，不进 R8
5. Android 15+ 的 systemWindowInsetTop 掺兼容层假 inset → 沉浸式用 stableInsetTop
6. `extractNativeLibs=false` 要求 lib/**/*.so 在 zip 内 16KB 页对齐
7. 手搓 Manifest AXML 必须含 RES_XML_RESOURCE_MAP，否则 PM 找不到 android:name

## 开发者

Seagull（海鸥）· AI Agent 构建链：javac + R8 + apksig + 手搓 AXML/arsc 编译器
