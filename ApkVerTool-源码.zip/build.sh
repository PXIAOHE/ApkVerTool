#!/bin/sh
# ApkVerTool 一键构建脚本（依赖见 README.md 的 libs/ 说明）
set -e
cd "$(dirname "$0")"

mkdir -p build/dex build/dex2 build/appclasses build/cli

echo "[1/6] javac 编译"
javac --release 8 -cp libs/android28.jar:libs/apksig.jar -d build/appclasses \
    src/com/seagull/avt/core/*.java src/com/seagull/avt/app/*.java
javac --release 8 -cp libs/apksig.jar -d build/cli \
    src/com/seagull/avt/core/*.java src/com/seagull/avt/cli/AvtCli.java

echo "[2/6] 打 jar"
jar cf build/app.jar -C build/appclasses .

echo "[3/6] R8 混淆 app 代码（core/类名混淆，apksig 走 classpath 不进混淆）"
java -cp libs/r8.jar com.android.tools.r8.R8 --release \
    --lib libs/android.jar --lib libs/android28.jar \
    --classpath libs/apksig.jar \
    --min-api 26 --pg-conf proguard-rules.pro \
    --output build/dex build/app.jar

echo "[4/6] D8 编译 apksig（独立 classes2.dex，不混淆）"
java -cp libs/r8.jar com.android.tools.r8.D8 --release \
    --lib libs/android.jar --lib libs/core-oj.jar --lib libs/core-libart.jar \
    --min-api 26 --output build/dex2 libs/apksig.jar

echo "[5/6] 生成图标 + resources.arsc + AndroidManifest.xml(AXML)"
python3 mkicon.py build
python3 mkaxml.py build/AndroidManifest.xml

echo "[6/6] 组包 + 签名"
python3 pack.py

echo "完成: build/ApkVerTool-v1.4.5.apk"
